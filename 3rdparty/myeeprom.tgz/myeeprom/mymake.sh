rm libmyeeprom.a
sync
/opt/i686-arago-linux/usr/bin/arm-linux-gnueabihf-gcc -c myeeprom.c -o myeeprom.o
/opt/i686-arago-linux/usr/bin/arm-linux-gnueabihf-ar rcs libmyeeprom.a myeeprom.o

